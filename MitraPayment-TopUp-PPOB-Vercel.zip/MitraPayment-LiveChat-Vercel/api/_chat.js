const DAY = 60 * 60 * 24;
const MAX_TEXT = 1000;
const CHAT_ID_RE = /^[a-zA-Z0-9_-]{8,100}$/;

function redisConfig() {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) throw new Error('Konfigurasi Redis belum lengkap.');
  return { url: url.replace(/\/+$/, ''), token };
}
async function redis(command) {
  const {url, token} = redisConfig();
  const response = await fetch(url, {
    method: 'POST',
    headers: {'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json'},
    body: JSON.stringify(command)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.error) throw new Error(data.error || 'Redis request gagal.');
  return data.result;
}
function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}
function validChatId(value) {
  return typeof value === 'string' && CHAT_ID_RE.test(value);
}
function cleanText(value) {
  return typeof value === 'string' ? value.trim().slice(0, MAX_TEXT) : '';
}
async function appendMessage(chatId, message) {
  const key = `mp:chat:${chatId}`;
  await redis(['RPUSH', key, JSON.stringify(message)]);
  await redis(['EXPIRE', key, DAY * 30]);
  await redis(['SADD', 'mp:chats', chatId]);
  await redis(['EXPIRE', 'mp:chats', DAY * 30]);
}
async function getMessages(chatId) {
  const rows = await redis(['LRANGE', `mp:chat:${chatId}`, '0', '-1']);
  return (rows || []).map(row => { try { return JSON.parse(row); } catch { return null; } }).filter(Boolean);
}
module.exports = {DAY,MAX_TEXT,CHAT_ID_RE,redis,json,validChatId,cleanText,appendMessage,getMessages};