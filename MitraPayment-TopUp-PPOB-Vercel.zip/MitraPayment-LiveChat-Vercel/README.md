# Mitra Payment — Website + Live Chat (Vercel)

## Isi paket
- `index.html` — landing page Mitra Payment yang diunggah, dipertahankan termasuk carousel, formulir pesanan, halaman Top Up, dan widget Live Chat.
- `admin.html` — panel admin untuk membaca dan membalas percakapan.
- `api/chat.js` — API publik untuk pesan pengunjung.
- `api/admin.js` — API admin yang dilindungi token.
- `api/_chat.js` — helper Redis bersama.

## Persiapan
1. Buat database Redis di Upstash dan salin REST URL serta REST token.
2. Buat token admin acak yang panjang (minimal 32 byte/64 karakter heksadesimal). Jangan gunakan contoh token dari chat atau menaruh token di HTML.
3. Di Vercel, buka project → Settings → Environment Variables. Tambahkan:
   - `UPSTASH_REDIS_REST_URL`
   - `UPSTASH_REDIS_REST_TOKEN`
   - `CHAT_ADMIN_TOKEN`
4. Pilih environment Production (tambahkan Preview juga bila diperlukan), simpan, lalu redeploy.

## Deploy
1. Ekstrak ZIP ini.
2. Impor folder project ke Vercel atau unggah melalui Git repository.
3. Gunakan Framework Preset `Other`. Tidak memerlukan build command.
4. Setelah deployment dan environment variables selesai, buka domain website.
5. Admin masuk melalui `https://DOMAIN-ANDA/admin.html` dan masukkan `CHAT_ADMIN_TOKEN`.

## Cara kerja chat
- Widget pengunjung mengirim pesan ke `/api/chat`.
- Admin membaca dan membalas melalui `/api/admin`.
- Pesan disimpan di Upstash Redis dan masa simpannya diperbarui menjadi 30 hari.
- Panel admin memuat ulang percakapan setiap 4 detik.

## Catatan penting
- Live Chat tidak berjalan jika HTML hanya dibuka sebagai file lokal di Android. Website harus di-deploy ke Vercel dan Redis harus dikonfigurasi.
- File ini belum di-deploy ke akun Vercel Anda. ZIP ini adalah paket sumber yang siap dikonfigurasi dan di-deploy.
- Informasi rekening/QRIS dan konfigurasi EmailJS yang sudah ada di HTML dipertahankan apa adanya. Pastikan semua tujuan pembayaran, merchant, dan template email memang milik/diotorisasi oleh Anda sebelum digunakan.
- Jangan pernah mengirim `CHAT_ADMIN_TOKEN` atau `UPSTASH_REDIS_REST_TOKEN` ke pengunjung atau memasukkannya ke HTML publik.


### Bukti Top Up / Deposit

Form bukti top up dikirim ke endpoint `/api/deposit` dan disimpan sementara di Upstash Redis selama 30 hari. Admin dapat melihat daftar ID akun, nominal, metode, keterangan, dan status awal "Menunggu verifikasi" pada panel admin. Bukti gambar diproses di browser menjadi JPEG sebelum dikirim. Jangan menganggap deposit berhasil sebelum staf memeriksa transaksi dan melakukan konfirmasi secara manual.


Pembaruan UI Top Up: pilihan bank ditampilkan dalam daftar kartu gaya aplikasi PPOB dengan urutan BCA, BRI, BNI, Mandiri, lalu Bank Lainnya. Logo Mandiri dan ATM Bersama menggunakan gambar yang disediakan pengguna. Bank BSI tidak ditampilkan.
